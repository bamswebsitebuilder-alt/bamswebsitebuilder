BAM'S WEBSITE BUILDER — ARCHIVOS EN ESPAÑOL CORREGIDOS

Sube toda esta carpeta como:
/es/

La estructura debe quedar así:
/es/index.html
/es/services.html
/es/prices.html
/es/portfolio.html
/es/reviews.html
/es/contact.html
/es/login.html
/es/register.html
/es/forgot-password.html
/es/client-portal.html
/es/admin-dashboard.html
/es/404.html

Los enlaces ahora usan direcciones limpias como:
/es/
/es/services
/es/portfolio

Los enlaces de idioma ahora conectan correctamente las páginas en inglés y español.
